﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TimeToDegree
{
    class Program
    {
        static void Main()
        {
            //a program to find the degree between the hour hand and minute hand given a time between 0000 and 2359
            bool condition ;
            int n;
            do
            {
                Console.WriteLine("Please enter a time between 0000 and 2359 (hours are 0 - 23, minutes are 0-60).");
                int.TryParse(Console.ReadLine(), out n);
                condition = Converter.CheckInput(n);                
            } while (!condition);  // loop will continue until proper input is entered
            Console.WriteLine("Degree is: " + "{0:#.##}", Converter.TimeConversion(n));
        }
        
    }
}
