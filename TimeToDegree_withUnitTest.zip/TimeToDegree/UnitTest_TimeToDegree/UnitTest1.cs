﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest_TimeToDegree
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
