﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeToDegree
{
    public class Converter
    {
        public static bool CheckInput(int n)
        {
            // input should be a valid hour and minute
            // Console.WriteLine("Please enter a time between 0000 and 2359 (hours are 0 - 23, minutes are 0-60).");
            //int.TryParse(Console.ReadLine(), out int n);
            if (n >= 0 && n <= 2359)  // confirm input is withing given range
            {
                if ((n / 100) <= 23 && n % 100 <= 60)  
                {
                    return true;
                }
                else return false;
            }
            else return false;
        }

        // method accounts for movment of hour hand for each passing minute
        public static double TimeConversion(int x)
        {   
            int min = x % 100;
            double hours = (x / 100);
            double degree = Math.Abs(hours * 30) - (min * 6) - (min*.5);
            if (degree > 180) return (360 - degree);
            else return degree;
        }
    }
}

