﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TimeToDegree;


namespace UnitTestTimeConverter
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestBadInput()
        {
            //enter an invalid time not within 00-23 hours 
            var testResult = Converter.CheckInput(9900);
            Assert.AreEqual(false, testResult);
        }
        [TestMethod]
        public void TestGoodInput()
        {
            //enter an invalid time not within 00-23 hours 
            var testResult = Converter.CheckInput(0600);
            Assert.AreEqual(true, testResult);
        }
        [TestMethod]
        public void TestMax()
        {
            //enter an invalid time not within 00-23 hours 
            var testResult = Converter.TimeConversion(2359);
            Assert.AreEqual(6.5, testResult);
        }
        [TestMethod]
        public void TestMin()
        {
            //enter an invalid time not within 00-23 hours 
            var testResult = Converter.TimeConversion(0000);
            Assert.AreEqual(0, testResult);
        }
        [TestMethod]
        public void TestGiven()
        {
            //enter an invalid time not within 00-23 hours 
            var testResult = Converter.TimeConversion(0345);
            Assert.AreEqual(180, testResult);
        }
    }
}
